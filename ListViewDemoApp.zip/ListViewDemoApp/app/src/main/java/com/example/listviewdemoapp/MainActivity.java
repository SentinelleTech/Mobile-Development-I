package com.example.listviewdemoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    String[] countries = {"Kenya", "Uganda", "Tanzania", "Egypt", "Mali", "Gabon", "Rwanda", "Congo", "Bukina Faso", "Zambia", "Zimbabwe", "South Africa",
    "Togo", "Libya"};
    ListView lv;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lv = findViewById(R.id.listViewExample);
        adapter = new ArrayAdapter<>(this, R.layout.activity_content, R.id.textView, countries);

        lv.setAdapter(adapter);
    }
}